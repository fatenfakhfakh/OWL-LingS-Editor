/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Domain_Ontology;
/**
 *
 * @author bwali
 */
import java.io.BufferedReader;
import java.io.FileReader;
import java.net.URI;
import java.util.AbstractSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;
import java.util.Vector;

import org.mindswap.pellet.jena.OWLReasoner;
import org.mindswap.pellet.owlapi.Reasoner;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.*;
import org.semanticweb.owlapi.reasoner.ConsoleProgressMonitor;
import org.semanticweb.owlapi.reasoner.NodeSet;
import org.semanticweb.owlapi.reasoner.OWLReasonerConfiguration;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;
import org.semanticweb.owlapi.reasoner.SimpleConfiguration;
import org.semanticweb.owlapi.util.SimpleIRIMapper;
import uk.ac.manchester.cs.owl.owlapi.OWLClassAssertionImpl;
import uk.ac.manchester.cs.owl.owlapi.OWLObjectPropertyAssertionAxiomImpl;
import uk.ac.manchester.cs.owl.owlapi.OWLObjectPropertyImpl;
import org.semanticweb.owlapi.model.OWLDataFactory;


public class Test_Faten_Extraction2 {

  
    	public Vector<OWLClass> V_Class = new Vector<OWLClass>();
//------Les vecteurs des sous classes ------------------------------------
    	public Vector<String>  V_SubClass_PL= new Vector<String>();
    	public	Vector<String>  V_SubClass_App= new Vector<String>();
    	public Vector<String>  V_SubClass_Analysis_Type= new Vector<String>();
    	public Vector<String> V_SubClass_Formalism= new Vector<String>();       
    	public Vector<String> V_SubClass_Language= new Vector<String>();
    	public Vector<String> V_SubClass_Phenomenon= new Vector<String>();
    	// public Vector<String> V_SubClass_S_Phenomenon1= new Vector<String>();   //Fatennnn--Apres--Zeid
    	public Vector<String> V_SubClass_Resource= new Vector<String>();
    	public Vector<String> V_SubClass_Treatment_Type= new Vector<String>();
//---------------------- Pour les sous Phenomenon --------------------------------------
    	//public static Vector<String>  V_SubClass_S_Phenomenon= new Vector<String>();
    	public static Vector<String>  V_SubClass_S_Phenomenon= new Vector<String>();
    	public Vector<String>  V_SubClass_S_Analysis_Type= new Vector<String>();
    	public Vector<String>  V_SubClass_S_Formalism= new Vector<String>();    
//---------------------------------------------------------------------------------------------------------   
    	public static final String ontologyIRI = "http://127.0.0.1/ontology/All_Domain_Ontology.owl"; //Je vais l'utiliser pour afficher les sous sous classe
//---------------------------------------------------------------------------------------------------------   
    	
    	
    	public void Affich_class_sub_class(){
    		 
         OWLOntology ontology = null;
        OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
        OWLDataFactory factory = manager.getOWLDataFactory();
        try {
        	System.out.println("-------------Test_Faten_Extraction2--------Main ---Try-------");

           //ontology = manager.loadOntology( IRI.create("http://127.0.0.1/ontology/Linguistic_Resources.owl") );   //Marche ---- Faten 
           //*ontology = manager.loadOntology( IRI.create("http://127.0.0.1/ontology/Linguistic_Domaain_Ontology.owl") ); //Faten--Marche Finalllllllllllllll
        	ontology = manager.loadOntology( IRI.create("http://127.0.0.1/ontology/All_Domain_Ontology.owl") ); //Faten--Toute Ontology
            
         
           for (OWLClass c : ontology.getClassesInSignature())
           { 
        	    //*if (c.toStringID().startsWith("http://127.0.0.1/ontology/Linguistic_Domaain_Ontology.owl#")) //Faten--Marche Finalllllllllllllll
        	   if (c.toStringID().startsWith("http://127.0.0.1/ontology/All_Domain_Ontology.owl#"))  //Faten--Toute Ontology
               { 
        	       
 //--------------- Extraction des noms des classes -------- des sous classes affich�es --------------------------------------       		   
        		   String class_id= c.toStringID();  //--Donne l'url d'une classe         
        	
//------------------- PL	------------------------------------------------------------------------------------
        		   if (c.toStringID().endsWith("Processing_Level")) 
        			   
        		   {
	        		   V_Class.addElement(c);	   
		        
		        	   V_SubClass_PL =get_SubClasses(c, ontology );
		        	  System.out.println ("******** V_SubClass_PL=====" + V_SubClass_PL);
	        		}
//------------------- Approach    -------------------------------------------------------------------------------- 		   
        		   else if (c.toStringID().endsWith("Approach")) 
        			   
        		   {
        			   V_Class.addElement(c);	   
	        		//++   System.out.println ("******** V_Class=====" + V_Class);
	        		   V_SubClass_App =get_SubClasses(c, ontology );
	        		    System.out.println ("******** V_SubClass_App=====" + V_SubClass_App);
        		   }
//------------------- Analysis_Type		--------------------------------------------------------------------------------
        		   else if (c.toStringID().endsWith("Analysis_Type")) 
        			   
        		   {
        			   V_Class.addElement(c);	   
	        		   System.out.println ("******** V_Class=====" + V_Class);
	        		   V_SubClass_Analysis_Type =get_SubClasses(c, ontology );
	        		   V_SubClass_S_Analysis_Type =get_SubClasses(c, ontology );
	        		 System.out.println ("******** V_SubClass_Analysis_Type=====" + V_SubClass_Analysis_Type);
        		   }
//------------------- Formalism		--------------------------------------------------------------------------------
        		   else if (c.toStringID().endsWith("Formalism")) 
        			   
        		   {
        			   V_Class.addElement(c);	   
	        		 //++  System.out.println ("******** V_Class=====" + V_Class);
	        		   V_SubClass_Formalism =get_SubClasses(c, ontology );
	        		   V_SubClass_S_Formalism =get_SubClasses(c, ontology );
	        		 //++  System.out.println ("******** V_SubClass_Formalism=====" + V_SubClass_Formalism);
        		   }
//------------------- Language	--------------------------------------------------------------------------------
        		   else if (c.toStringID().endsWith("Language")) 
        			   
        		   {
        			   V_Class.addElement(c);	   
	        		 //++  System.out.println ("******** V_Class=====" + V_Class);
	        		   V_SubClass_Language =get_SubClasses(c, ontology );
	        		  //System.out.println ("******** V_SubClass_Language=====" + V_SubClass_Language);
        		   }
        		   
        		   
        		   
        		 //------------------- Resource		--------------------------------------------------------------------------------
        		   else if (c.toStringID().endsWith("Resource")) 
        			   
        		   {
        			   V_Class.addElement(c);	   
	        		 //++  System.out.println ("******** V_Class=====" + V_Class);
	        		   V_SubClass_Resource =get_SubClasses(c, ontology );
	        		 //++  System.out.println ("******** V_SubClass_Resource=====" + V_SubClass_Resource);
        		   }
//------------------- Treatment_Type	--------------------------------------------------------------------------------
        		   else if (c.toStringID().endsWith("Treatment_Type")) 
        			   
        		   {   System.out.println ("******** Treatment_Type **************");
        			   V_Class.addElement(c);	   
	        		     System.out.println ("******** V_Class=====" + V_Class);
	        		   V_SubClass_Treatment_Type =get_SubClasses(c, ontology );
	        		   System.out.println ("******** V_SubClass_Treatment_Type=====" + V_SubClass_Treatment_Type);
        		   }
        		   
         		   
        		   
//------------------- Phenomenon	--------------------------------------------------------------------------------
        		   else if (c.toStringID().endsWith("Phenomenon"))   
        		   { System.out.println ("*11111***��****ontology.getSubClassAxiomsForSubClass(c) ======"+ ontology.getSubClassAxiomsForSubClass(c));
       			
        			   V_Class.addElement(c);	   
	        		  //++ System.out.println ("******** V_Class=====" + V_Class);
	        		 //*****  V_SubClass_Phenomenon =get_SubClasses(c, ontology );
	        		  // V_SubClass_Phenomenon1=get_SubClasses_OWLClass(c, ontology );    //---------Faten -----Apres 
        			   V_SubClass_Phenomenon =get_SubClasses(c, ontology );
		        		  
	        		   ////** V_SubClass_S_Phenomenon =get_SubClasses(V_SubClass_Phenomenon.get(0), ontology);
	        		    //Set<OWLClassExpression> V_Class2 = V_Class.get(0).getSubClasses(ontology);
	        		    
	        		 //   V_SubClass_S_Phenomenon =get_SubClasses(V_Class2.getClass(), ontology); //--- Faten ------- Apres -------
	        		    System.out.println ("******** V_SubClass_Phenomenon====������===" + V_SubClass_Phenomenon);
	        		    System.out.println ("******** V_SubClass_Phenomenon.size() =====" + V_SubClass_Phenomenon.size());
	        		    	    
	        		    Vector <String> name_classOWL_vector=new Vector <String> ();
	        		    for (int i=0;i<V_SubClass_Phenomenon.size();i++){
		        			   System.out.println ("******** ����� V_SubClass_Phenomenon.get(i) ����====" + V_SubClass_Phenomenon.get(i));
		        			   		
		        			   		String sub_class=V_SubClass_Phenomenon.get(i);
		        			   	        				    
		        				    name_classOWL_vector.add(sub_class);
		        				    System.out.println("name_classOWL_vector===================== " + name_classOWL_vector);
		        				    //getSubSubClass(ontologyIRI, name_classOWL);		    
//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		        				    OWLOntologyManager manager2 = OWLManager.createOWLOntologyManager();
		        			        OWLOntology ontology2 = null;
		        					try {
		        						ontology2 = manager2.loadOntologyFromOntologyDocument(IRI.create(ontologyIRI));
		        					} catch (Exception e) {
		        						// TODO Auto-generated catch block
		        						e.printStackTrace();
		        					}
		        			    	  OWLDataFactory factory2 = manager2.getOWLDataFactory();
		        			    	  //printing specific subclasses
		        			          //OWLClass domainConcept = factory.getOWLClass(IRI.create(ontologyIRI + name_classOWL));
		        			    	  OWLClass domainConcept = factory2.getOWLClass(IRI.create(sub_class));
		        			          System.out.println("Start printing Specific Subclass from the OWLClass " + domainConcept);
		        			         
		        			        
		        			          getSubClass(ontology, domainConcept);

	        		    }    	
	        			     }
	        		    
//********************FFFFFFFFFFFFFFFFFFFFFFFFFFFf******************************************	        		   

        		   }
//------------------- Resource		--------------------------------------------------------------------------------
/*        		   else if (c.toStringID().endsWith("Resource")) 
        			   
        		   {
        			   V_Class.addElement(c);	   
	        		 //++  System.out.println ("******** V_Class=====" + V_Class);
	        		   V_SubClass_Resource =get_SubClasses(c, ontology );
	        		 //++  System.out.println ("******** V_SubClass_Resource=====" + V_SubClass_Resource);
        		   }
//------------------- Treatment_Type	--------------------------------------------------------------------------------
        		   else if (c.toStringID().endsWith("Treatment_Type")) 
        			   
        		   {   System.out.println ("******** Treatment_Type **************");
        			   V_Class.addElement(c);	   
	        		     System.out.println ("******** V_Class=====" + V_Class);
	        		   V_SubClass_Treatment_Type =get_SubClasses(c, ontology );
	        		   System.out.println ("******** V_SubClass_Treatment_Type=====" + V_SubClass_Treatment_Type);
        		   }
*/
//------------------- sous Phenomenon --------------------------Le 28/10/2012 ----------------
       /*
        		   else if (c.toStringID().endsWith("Ellipsis")) 
        			   
        		   {
        			   V_Class.addElement(c);	   
	        		    System.out.println ("******** V_Class=====" + V_Class);
        			   for(int i=0;i<V_SubClass_Phenomenon.size();i++){
        			    V_SubClass_S_Phenomenon =get_SubClasses((OWLClass) get_SubClasses(c, ontology ), ontology );
	        		    System.out.println ("******** V_SubClass_S_Phenomenon=====" + V_SubClass_S_Phenomenon);
        			    }
        		   }            		   
        //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         Set<Set<OWLClass>> results = r.getSubClasses(a);
//            for (Set<OWLClass> result : results){
//                logger.debug("result = " + result);
         */
//------------------- -------------------------FFFFF SSSS---------------------------------
        		      ////for (OWLClass c2 : ontology.getSubClassAxiomsForSubClass(cls)){
        	        		 //  OWLClass subEllipsis=get_SubClasses(c, ontology);
        	           	 /* else if (c.toStringID().endsWith("Phenomenon")) 
        	        			   
        	        		   { System.out.println ("******** Phenomenon **************");
        	        			   V_Class.addElement(c);	   
        		        		    System.out.println ("******** V_Class==Ellipsis===" + V_Class);
        	        			   for(int i=0;i<V_SubClass_Phenomenon.size();i++){
        	        			    V_SubClass_S_Phenomenon =get_SubClasses((OWLClass) get_SubClasses(c, ontology ), ontology );
        		        		     System.out.println ("******** V_SubClass_S_Phenomenon=====" + V_SubClass_S_Phenomenon);
        	        			    }
        	        		   } 
        	        	*/
        	        //}
 //----------------------------------************************************            
 	               }
           }
        
        catch (OWLException e) {
            e.printStackTrace();
        }
     }
 
    public static Vector<String> get_SubClasses(OWLClass c1, OWLOntology ontology ){
    	Vector <String> sub_c=new Vector <String> ();
    	Set<OWLSubClassOfAxiom> sub_classes= ontology.getSubClassAxiomsForSuperClass(c1);
    	//System.out.println ("*** ontology.getSubClassAxiomsForSuperClass("+c1 +") ======"+ontology.getSubClassAxiomsForSuperClass(c));  //Faten --je veux tester subclass
    	Iterator iter = sub_classes.iterator();
    	while (iter.hasNext()) {
    		OWLSubClassOfAxiom sub_class=(OWLSubClassOfAxiom) iter.next();
    		
    		int pos_inferieur= sub_class.toString().indexOf("<");
		    
		    int pos_superieur= sub_class.toString().indexOf(">");
		    String name_sub_class=sub_class.toString().substring(pos_inferieur+1, pos_superieur);
		    System.out.println ("@@@@@@@@@@@@@@@ name_sub_class ==========="+ name_sub_class);
    		sub_c.add(name_sub_class);
     	}
    	return sub_c;

    }
//----------------------------------------------------- Apres -------------------------------------------------------
/*    public static Vector<OWLClass> get_SubClasses_OWLClass(OWLClass c1, OWLOntology ontology ){
    	//Vector <OWLClass> sub_c=new Vector <OWLClass> ();
    	Vector <OWLSubClassOfAxiom> sub_c=new Vector <OWLSubClassOfAxiom> ();
    	Set<OWLSubClassOfAxiom> sub_classes= ontology.getSubClassAxiomsForSuperClass(c1);
    	//Set<OWLClass> sub_classes2= ontology.getSubClassAxiomsForSuperClass(c1).getClass();
    	//System.out.println ("*** ontology.getSubClassAxiomsForSuperClass("+c1 +") ======"+ontology.getSubClassAxiomsForSuperClass(c));  //Faten --je veux tester subclass
    	Iterator iter = sub_classes.iterator();
    	while (iter.hasNext()) {
    		OWLSubClassOfAxiom sub_class=(OWLSubClassOfAxiom) iter.next();
    		
    		//int pos_inferieur= sub_class.toString().indexOf("<");
		    
		    //int pos_superieur= sub_class.toString().indexOf(">");
		    //String name_sub_class=sub_class.toString().substring(pos_inferieur+1, pos_superieur);
		    
    		//sub_c.add(name_sub_class);
			//sub_c.set(index, element)
		    //sub_c.add(0, (OWLClass) sub_class);
    		 sub_c.addElement(sub_class);
		    System.out.println ("*** **********  sub_c.get(0)  ========"+ sub_c.get(0));
		    System.out.println ("*** **********  sub_c.get(1)  ========"+ sub_c.get(1));
     	}
    	return sub_c;
    }
 */
    //////////////////////////////////////////
    private static OWLSubClassOfAxiom findSubClassAxiom(OWLDataFactory factory, OWLOntologyManager manager, OWLOntology ontology, OWLClass subClass, OWLClass superClass)
    {
    	for(OWLClassExpression i : superClass.getSubClasses(ontology))
    	{
    		if(i == subClass)
    		{	System.out.println ("*** **********  factory.getOWLSubClassOfAxiom(subClass, superClass) ========"+ factory.getOWLSubClassOfAxiom(subClass, superClass));
    			return factory.getOWLSubClassOfAxiom(subClass, superClass);
    		}
    	}
    	return null;
    }   
//----------------------------------------------------- Fin Apres -------------------------------------------------------
//************** Apres  ****************   Le 13/12/2012  ***************************
    public static void setSubClass(OWLDataFactory factory, OWLOntologyManager manager, OWLOntology ontology, OWLClass subClass, OWLClass superClass)
    {
    	manager.addAxiom(ontology, factory.getOWLSubClassOfAxiom(subClass, superClass));
    }
//--    
    public static void getSubClass(OWLOntology ontology, OWLClass classOWL)
    {	//......V_SubClass_S_Phenomenon.clear();   //Suppp Finnn
    	for(OWLClassExpression i : classOWL.getSubClasses(ontology))
    	{
    		System.out.println(" PPPPPP " + i);
    		
//???????????????????????????????????????????????????????
    		int pos_inferieur= i.toString().indexOf("<");
		    
		    int pos_superieur= i.toString().indexOf(">");
		    String name_sub_class=i.toString().substring(pos_inferieur+1, pos_superieur);
		    System.out.println ("@@@@@@@@@@@@@@@ name_sub_class =====111======"+ name_sub_class);
		    V_SubClass_S_Phenomenon.add(name_sub_class);
		 
    //Le prob ici !!!		
    		
    	}
    	   System.out.println ("@@@@@@@@@@@@@@@ V_SubClass_S_Phenomenon ==========="+ V_SubClass_S_Phenomenon); //Affichage juste puis faux
    }
    
 //-------------------- Faten ----------------	Donner les sous classe d'une classe (�ad les sous classes d'un Phenomenon)    
/*    public static void getSubSubClass(String ontologyIRI, String name_classOWL)
    {
    	OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
        OWLOntology ontology = null;
		try {
			ontology = manager.loadOntologyFromOntologyDocument(IRI.create(ontologyIRI));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	  OWLDataFactory factory = manager.getOWLDataFactory();
    	  //printing specific subclasses
          OWLClass domainConcept = factory.getOWLClass(IRI.create(ontologyIRI + name_classOWL));
          System.out.println("Start printing Specific Subclass from the OWLClass " + domainConcept);
          getSubClass(ontology, domainConcept);
         // System.out.println("*************** getSubClass(ontology, domainConcept) ===="+ getSubClass(ontology, domainConcept));
        
    }
*/
//************** Fin   Apres  ****************   
  //---------------------------------------
    public static void main(String[] args) throws OWLOntologyCreationException {
    	Test_Faten_Extraction2 te=new Test_Faten_Extraction2();
    	te.Affich_class_sub_class();
/////************************************************* Apres *************
/*    	  String ontologyIRI = "http://127.0.0.1/ontology/All_Domain_Ontology.owl";
    	  //public static final String ontologyIRI = "http://127.0.0.1/ontology/All_Domain_Ontology.owl";
    	OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
        OWLOntology ontology = null;
		try {
			ontology = manager.loadOntologyFromOntologyDocument(IRI.create(ontologyIRI));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	  OWLDataFactory factory = manager.getOWLDataFactory();
    	  //printing specific subclasses
          OWLClass domainConcept = factory.getOWLClass(IRI.create(ontologyIRI + "#Anaphora"));
          System.out.println("Start printing Specific Subclass from the OWLClass " + domainConcept);
          getSubClass(ontology, domainConcept);
         // System.out.println("*************** getSubClass(ontology, domainConcept) ===="+ getSubClass(ontology, domainConcept));
        
*/   
        
    }
}