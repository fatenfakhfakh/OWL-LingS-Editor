package impl.owls.profile;

import impl.owl.WrappedIndividual;

import org.mindswap.owl.OWLIndividual;
import org.mindswap.owls.profile.Language;
import org.mindswap.owls.vocabulary.OWLS;


public class LanguageImpl extends WrappedIndividual	implements Language {
	public LanguageImpl(OWLIndividual ind) {
		super(ind);
	}

	public String getLanguageName() {
		return getPropertyAsString(OWLS.Profile.languageName);
	}
   public void setLanguageName(String name) {
        setProperty(OWLS.Profile.languageName, name);
    }

	public OWLIndividual getSLanguage() {
		return getProperty(OWLS.Profile.sLanguage);
	}
 
	public void setLanguage(OWLIndividual value) {
        setProperty(OWLS.Profile.sLanguage, value);
    }
//--------------------------------------------------------------------------------------
    public Language getLanguage() {
        return (Language) getPropertyAs(OWLS.Profile.has_Language, Language.class);
    }
    public void setLanguage(Language language) {
        setProperty(OWLS.Profile.has_Language, language);
    }  
	public void addLanguage(Language language) {
		  System.out.println("**********   LanguageImpl   *****"+OWLS.Profile.has_Language);
	    addProperty(OWLS.Profile.has_Language, language);
	}

}