package impl.owls.profile;

import impl.owl.WrappedIndividual;
import org.mindswap.owl.OWLIndividual;
import org.mindswap.owls.profile.Analysis_Type;
import org.mindswap.owls.profile.Approach;
import org.mindswap.owls.profile.LinguisticFormalism;
import org.mindswap.owls.vocabulary.OWLS;


public class LinguisticFormalismImpl extends WrappedIndividual	implements LinguisticFormalism {
	public LinguisticFormalismImpl(OWLIndividual ind) {
		super(ind);
	}

	public String getFormalismName() {
		return getPropertyAsString(OWLS.Profile.FormalismName);
	}
	public void setFormalismName(String name) {
		 setProperty(OWLS.Profile.FormalismName, name);
		
	}
	public OWLIndividual getFormalism() {
		return getProperty(OWLS.Profile.sFormalism);
	}
 
	public void setFormalism(OWLIndividual value) {
        setProperty(OWLS.Profile.sFormalism, value);
    }
//--------------------------------------------------------------------------------------
    public LinguisticFormalism getLinguisticFormalism() {
        return (LinguisticFormalism) getPropertyAs(OWLS.Profile.supported_By, LinguisticFormalism.class);
    }
    public void setLinguisticFormalism(LinguisticFormalism formalism) {
        setProperty(OWLS.Profile.supported_By, formalism);
    }  
	public void addLinguisticFormalism(LinguisticFormalism formalism) {
		  System.out.println("**********   LinguisticFormalismImpl   *****"+OWLS.Profile.supported_By);
	    addProperty(OWLS.Profile.supported_By, formalism);
	}
//------------	@@@@@@@@@@@ Ajout� par Faten Le 28/07/2012  @@@@@@@@@@@@@@@@@@@@@@ Si on veut Analysis_Type dans LinguisticFormalism
	public void addAnalysis_Type(Analysis_Type analysis_Type){
		System.out.println("********** OWLS.Profile.has_Analysis_Type   *****"+ OWLS.Profile.has_Analysis_Type);
    addProperty(OWLS.Profile.has_Analysis_Type, analysis_Type);
}	
}