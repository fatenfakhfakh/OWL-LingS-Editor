package impl.owls.profile;

import impl.owl.WrappedIndividual;

import org.mindswap.owl.OWLIndividual;
import org.mindswap.owls.process.ControlConstruct;
import org.mindswap.owls.profile.LinguisticPhenomenon;

import org.mindswap.owls.profile.Resource_Ling;
import org.mindswap.owls.profile.ServiceCategory;
import org.mindswap.owls.profile.ServiceProcessing_Level;
import org.mindswap.owls.vocabulary.OWLS;


//public class ServiceProcessing_LevelImpl extends ProfileImpl implements ServiceProcessing_Level {
//public class ServiceProcessing_LevelImpl extends ServiceParameterImpl implements ServiceProcessing_Level {  //Le 13/07/2012
/* ********		J'ai fais extends: "ServiceParameterImpl" comme: Split, Choice, ....  **********	*/


//--- Je vais pas utiliser la Relation d'h�ritage -------	 			
public class ServiceProcessing_LevelImpl  extends WrappedIndividual implements ServiceProcessing_Level {
	
	
    public ServiceProcessing_LevelImpl(OWLIndividual ind) {
		super(ind);		
	}
    
//----------------------------------- Fin ---------------------------------
	/// A terminer ?????
	//public String getCommentary() {
		//return getPropertyAsString(OWLS.Profile.serviceParameterName);
		//return getPropertyAsString(OWLS.Profile.ServiceProcessing_Level);
	//}
	
	public String getName() {
		System.out.println("= ServiceProcessing_Level==== getName()=====");
		return getPropertyAsString(OWLS.Profile.commentary);
	}
    public void setName(String name) {
	        setProperty(OWLS.Profile.commentary, name);
	    }
    
  //--- Je vais pas utiliser la Relation d'h�ritage. Donc, je vais d�finir ces 2 Attributs  -------	
	public String getName2() {
		return getPropertyAsString(OWLS.Profile.serviceParameterName2);
	}
	public OWLIndividual getParameter2() {
		return getProperty(OWLS.Profile.sParameter2);
	}
    
    public void setName2(String name) {
        setProperty(OWLS.Profile.serviceParameterName2, name);
    }

    public void setParameter2(OWLIndividual value) {
        setProperty(OWLS.Profile.sParameter2, value);
    }

    public void setHasPhenomenon(LinguisticPhenomenon phenomenon) {
        setProperty(OWLS.Profile.hasPhenomenon, phenomenon);
    }

    public LinguisticPhenomenon getHasPhenomenon() {
    	return (LinguisticPhenomenon) getPropertyAs(OWLS.Profile.hasPhenomenon, LinguisticPhenomenon.class);
    }
//------------	@@@@@@@@@@@ Ajout� par Faten Le 27/07/2012  @@@@@@@@@@@@@@@@@@@@@@ Si on veut Resource dans ServiceProcessing_Level

    public void addResource(Resource_Ling resource1) {
    	 System.out.println("********** ResourceImpl*****"+ OWLS.Profile.hasResource);
    	addProperty(OWLS.Profile.hasResource, resource1);
    }
    public void addLinguisticPhenomenon(LinguisticPhenomenon phenomenon){
		System.out.println("********** OWLS.Profile.hasPhenomenon*****"+ OWLS.Profile.hasPhenomenon);
    addProperty(OWLS.Profile.hasPhenomenon, phenomenon);
}	
    
/*
 public class SimpleProcessImpl extends ProcessImpl implements SimpleProcess {
    public SimpleProcessImpl(OWLIndividual ind) {
        super(ind);
    }
    public AtomicProcess getAtomicProcess() {
        return (AtomicProcess) getPropertyAs(OWLS.Process.realizedBy, AtomicProcess.class);
    }
    public CompositeProcess getCompositeProcess() {
        return (CompositeProcess) getPropertyAs(OWLS.Process.expandsTo, CompositeProcess.class);
    }
    public void setAtomicProcess(AtomicProcess process) {
        setProperty(OWLS.Process.realizedBy, process);
    }
    public void setCompositeProcess(CompositeProcess process) {
        setProperty(OWLS.Process.expandsTo, process);
    }

 */
/*	********************************************************	*/
/////  Il faut mettre ici:
////	get+ add + set Phenomenon
/*	********************************************************	*/

}



