package impl.owls.profile;

import impl.owl.WrappedIndividual;

import org.mindswap.owl.OWLIndividual;
import org.mindswap.owls.profile.Treatment_Type;
import org.mindswap.owls.vocabulary.OWLS;


public class Treatment_TypeImpl extends WrappedIndividual	implements Treatment_Type {
	public Treatment_TypeImpl(OWLIndividual ind) {
		super(ind);
	}

	public String getTreatment_TypeName() {
		return getPropertyAsString(OWLS.Profile.Treatment_TypeName);
	}
   public void setTreatment_TypeName(String name) {
        setProperty(OWLS.Profile.Treatment_TypeName, name);
    }

	public OWLIndividual getSTreatment_Type() {
		return getProperty(OWLS.Profile.sTreatment_Type);
	}
 
	public void setTreatment_Type(OWLIndividual value) {
        setProperty(OWLS.Profile.sTreatment_Type, value);
    }
//--------------------------------------------------------------------------------------
    public Treatment_Type getTreatment_Type() {
        return (Treatment_Type) getPropertyAs(OWLS.Profile.has_Treatment_Type, Treatment_Type.class);
    }
    public void setTreatment_Type(Treatment_Type treatment_Type) {
        setProperty(OWLS.Profile.has_Treatment_Type, treatment_Type);
    }  
	public void addTreatment_Type(Treatment_Type treatment_Type) {
		  System.out.println("**********   Treatment_TypeImpl   *****"+OWLS.Profile.has_Treatment_Type);
	    addProperty(OWLS.Profile.has_Treatment_Type, treatment_Type);
	}

}