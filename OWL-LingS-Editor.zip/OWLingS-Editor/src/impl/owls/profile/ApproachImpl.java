package impl.owls.profile;

import impl.owl.WrappedIndividual;

import org.mindswap.owl.OWLIndividual;
import org.mindswap.owls.profile.Approach;
import org.mindswap.owls.vocabulary.OWLS;


public class ApproachImpl extends WrappedIndividual	implements Approach {
	public ApproachImpl(OWLIndividual ind) {
		super(ind);
	}

	public String getApproachName() {
		return getPropertyAsString(OWLS.Profile.ApproachName);
	}
   public void setApproachName(String name) {
        setProperty(OWLS.Profile.ApproachName, name);
    }

	public OWLIndividual getSApproach() {
		return getProperty(OWLS.Profile.sApproach);
	}
 
	public void setApproach(OWLIndividual value) {
        setProperty(OWLS.Profile.sApproach, value);
    }
//--------------------------------------------------------------------------------------
    public Approach getApproach() {
        return (Approach) getPropertyAs(OWLS.Profile.treated_By, Approach.class);
    }
    public void setApproach(Approach approach) {
        setProperty(OWLS.Profile.treated_By, approach);
    }  
	public void addApproach(Approach approach) {
		  System.out.println("**********   ApproachImpl   *****"+OWLS.Profile.treated_By);
	    addProperty(OWLS.Profile.treated_By, approach);
	}
//---------------------------Annotation pointeur -----------Le 15/10/2012----------------
    public void setApproach_pointer(Approach approach) {
        setProperty(OWLS.Profile.sApproach, approach);
    }  

}