package impl.owls.profile;

import impl.owl.WrappedIndividual;

import org.mindswap.owl.OWLIndividual;
import org.mindswap.owls.profile.Approach;
import org.mindswap.owls.profile.LinguisticFormalism;
import org.mindswap.owls.profile.LinguisticPhenomenon;
import org.mindswap.owls.vocabulary.OWLS;

//public class LinguisticPhenomenonImpl  extends WrappedIndividual	implements LinguisticPhenomenon {
public class LinguisticPhenomenonImpl  extends ProfileImpl	implements LinguisticPhenomenon {
	
	public LinguisticPhenomenonImpl(OWLIndividual ind) {
		super(ind);
	}
	public String getName() {
		return getPropertyAsString(OWLS.Profile.linguisticPhenomenonName);		
	}
	//public OWLIndividual getParameter() {
		//return getProperty(OWLS.Profile.sParameter); //******** Je crois, il faut modifier "sParameter" par la relation "supported_By" 
													 //********* ou "refined_into"
	//}
    public void setName(String name) {
        setProperty(OWLS.Profile.linguisticPhenomenonName, name);
    }
//----------------------- Faten Seul: Le 23/07/2012 ------------------------------------------------------------------
	public OWLIndividual getPhenomenon() {
		return getProperty(OWLS.Profile.sPhenomenon);
	}
	public void setPhenomenon(OWLIndividual value){
		 setProperty(OWLS.Profile.sPhenomenon, value);
	}
//------------	@@@@@@@@@@@ Ajout� par Faten Le 28/07/2012  @@@@@@@@@@@@@@@@@@@@@@ Si on veut LinguisticFormalism dans LinguisticPhenomenon
	public void addLinguisticFormalism(LinguisticFormalism formalism){
		System.out.println("********** OWLS.Profile.supported_By   *****"+ OWLS.Profile.supported_By);
    addProperty(OWLS.Profile.supported_By, formalism);
}	

   public void addApproach(Approach approach){
		System.out.println("********** OWLS.Profile.treated_By   *****"+ OWLS.Profile.treated_By);
    addProperty(OWLS.Profile.treated_By, approach);
}	
   
	public void addLinguisticPhenomenon(LinguisticPhenomenon phenomenon){
		System.out.println("********** OWLS.Profile.refined_Into   *****"+ OWLS.Profile.refined_Into);
    addProperty(OWLS.Profile.refined_Into, phenomenon);
}		
/*
 public class CompositeProcessImpl extends ProcessImpl implements CompositeProcess {
	public CompositeProcessImpl(OWLIndividual ind) {
		super(ind);
	}
	public ControlConstruct getComposedOf() {		
		return (ControlConstruct) getPropertyAs(OWLS.Process.composedOf, ControlConstruct.class);
	}
	public void setComposedOf(ControlConstruct construct) {
	    setProperty(OWLS.Process.composedOf, construct);
	}    
 */
    
//    public void setPhenomenon(OWLIndividual value) {
//        setProperty(OWLS.Profile.sParameter, value);//***********Je crois, il faut modifier "sParameter" par la relation "supported_By" 
        											//*********** ou "refined_into"
//    }
    	
// ******** Faten ****** Le 16/10/2012  ************************				  
	public void setApproach_pointer(Approach value){
		 addProperty(OWLS.Profile.sApproach, value);
	}
	
}
