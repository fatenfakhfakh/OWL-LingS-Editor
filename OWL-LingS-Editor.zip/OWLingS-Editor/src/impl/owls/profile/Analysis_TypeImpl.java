package impl.owls.profile;

import impl.owl.WrappedIndividual;

import org.mindswap.owl.OWLIndividual;
import org.mindswap.owls.profile.Analysis_Type;
import org.mindswap.owls.profile.Approach;
import org.mindswap.owls.vocabulary.OWLS;

public class Analysis_TypeImpl extends WrappedIndividual implements Analysis_Type {
	public Analysis_TypeImpl(OWLIndividual ind) {
		super(ind);                       
	}
	public String getAnalysis_TypeName() {
		return getPropertyAsString(OWLS.Profile.Analysis_TypeName);  
	}
   public void setAnalysis_TypeName(String name) {
        setProperty(OWLS.Profile.Analysis_TypeName, name);
    }

	public OWLIndividual getSAnalysis_Type() {
		return getProperty(OWLS.Profile.sAnalysis_Type);
	}
 
	public void setSAnalysis_Type(OWLIndividual value) {
        setProperty(OWLS.Profile.sAnalysis_Type, value);
    }
//--------------------------------------------------------------------------------------
    public Analysis_Type getAnalysis_Type() {
        return (Analysis_Type) getPropertyAs(OWLS.Profile.has_Analysis_Type, Analysis_Type.class);
    }
    public void setAnalysis_Type(Analysis_Type analysis_Type) {
        setProperty(OWLS.Profile.has_Analysis_Type, analysis_Type);
    }  
	public void addAnalysis_Type(Analysis_Type analysis_Type) {
		  System.out.println("**********   Analysis_Type   *****"+OWLS.Profile.has_Analysis_Type);
	    addProperty(OWLS.Profile.has_Analysis_Type, analysis_Type);
	}

}
