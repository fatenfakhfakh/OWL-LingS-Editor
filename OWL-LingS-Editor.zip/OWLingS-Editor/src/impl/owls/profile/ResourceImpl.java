package impl.owls.profile;

import impl.owl.WrappedIndividual;

import org.mindswap.owl.OWLIndividual;
import org.mindswap.owls.profile.Resource_Ling;
import org.mindswap.owls.profile.Resource_Ling;
import org.mindswap.owls.profile.ServiceProcessing_Level;
import org.mindswap.owls.vocabulary.OWLS;


public class ResourceImpl extends WrappedIndividual	implements Resource_Ling {
	public ResourceImpl(OWLIndividual ind) {
		super(ind);
	}

	public String getResourceName() {
		return getPropertyAsString(OWLS.Profile.ResourceName);
	}
   public void setResourceName(String name) {
        setProperty(OWLS.Profile.ResourceName, name);
    }

	public OWLIndividual getSResource() {
		return getProperty(OWLS.Profile.sResource);
	}
 
     public void setSResource(OWLIndividual value) {
        setProperty(OWLS.Profile.sResource, value);
    }

//------Faten ------------------------------------ Le 23/07/2012 -----------------------------	
    public Resource_Ling getResource() {
        return (Resource_Ling) getPropertyAs(OWLS.Profile.hasResource, Resource_Ling.class);
    }
    public void setResource(Resource_Ling resource) {
        setProperty(OWLS.Profile.hasResource, resource);
    }  
	public void addResource(Resource_Ling resource) {
		  System.out.println("**********   ResourceImpl   *****"+OWLS.Profile.hasResource);
	    addProperty(OWLS.Profile.hasResource, resource);
	}

}
