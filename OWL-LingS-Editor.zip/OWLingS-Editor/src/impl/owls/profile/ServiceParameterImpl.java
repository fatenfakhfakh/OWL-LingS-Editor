// The MIT License
//
// Copyright (c) 2004 Evren Sirin
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to
// deal in the Software without restriction, including without limitation the
// rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
// sell copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.

/*
 * Created on Mar 11, 2004
 */
package impl.owls.profile;

import impl.owl.WrappedIndividual;

import org.mindswap.owl.OWLIndividual;
import org.mindswap.owl.OWLObjectProperty;
import org.mindswap.owls.profile.Approach;
import org.mindswap.owls.profile.Language;
import org.mindswap.owls.profile.LinguisticPhenomenon;
import org.mindswap.owls.profile.Resource_Ling;
import org.mindswap.owls.profile.ServiceParameter;
import org.mindswap.owls.profile.ServiceProcessing_Level;
import org.mindswap.owls.profile.Treatment_Type;
import org.mindswap.owls.vocabulary.OWLS;

/**
 * @author Evren Sirin
 */
public class ServiceParameterImpl extends WrappedIndividual	implements ServiceParameter {
	/**
	 * @param resource
	 */
	public ServiceParameterImpl(OWLIndividual ind) {
		super(ind);
	}

	/* (non-Javadoc)
	 * @see org.mindswap.owls.profile.ServiceParameter#getName()
	 */
	public String getName() {
		return getPropertyAsString(OWLS.Profile.serviceParameterName);
	}

	/* (non-Javadoc)
	 * @see org.mindswap.owls.profile.ServiceParameter#getParameter()
	 */
	public OWLIndividual getParameter() {
		return getProperty(OWLS.Profile.sParameter);
	}

    /* (non-Javadoc)
     * @see org.mindswap.owls.profile.ServiceParameter#setName(java.lang.String)
     */
    public void setName(String name) {
        setProperty(OWLS.Profile.serviceParameterName, name);
    }

    /* (non-Javadoc)
     * @see org.mindswap.owls.profile.ServiceParameter#setParameter(org.mindswap.owl.OWLIndividual)
     */
    public void setParameter(OWLIndividual value) {
        setProperty(OWLS.Profile.sParameter, value);
    }
    
//---------------------- Si je vais pas consid�rer la relation d'h�ritage ----------------------------
/*    public void setHasProcessing_Level(ServiceProcessing_Level level) {
        setProperty(OWLS.Profile.hasProcessing_Level, level);
    }
    public ServiceProcessing_Level getHasProcessing_Level() {
    	return (ServiceProcessing_Level) getPropertyAs(OWLS.Profile.hasProcessing_Level, ServiceProcessing_Level.class);
    }
*/
    public ServiceProcessing_Level getServiceProcessing_Level() {
        return (ServiceProcessing_Level) getPropertyAs(OWLS.Profile.hasProcessing_Level, ServiceProcessing_Level.class);
    }
    public void setServiceProcessing_Level(ServiceProcessing_Level profile) {
        setProperty(OWLS.Profile.hasProcessing_Level, profile);
    }  
//---------------------------------------------------------------------------------------------------
//------------	@@@@@@@@@@@ Ajout� par Faten Le 27/07/2012  @@@@@@@@@@@@@@@@@@@@@@ Si on veut Approach dans SP
  //----
	public void addServiceProcessing_Level(ServiceProcessing_Level servicePL) {
		System.out.println("********** OWLS.Profile.hasProcessing_Level*****"+OWLS.Profile.hasProcessing_Level);
	
	        addProperty(OWLS.Profile.hasProcessing_Level, servicePL);
	}
  //----
    public void addApproach(Approach approach){
		System.out.println("********** OWLS.Profile.treated_By   *****"+ OWLS.Profile.treated_By);
    addProperty(OWLS.Profile.treated_By, approach);
}	
	public Approach getApproach(){
		return (Approach) getPropertyAs(OWLS.Profile.treated_By, Approach.class);
	}
//------
	public void addLanguage(Language language) {
		System.out.println("********** OWLS.Profile.has_Language*****"+OWLS.Profile.has_Language);
	
	        addProperty(OWLS.Profile.has_Language, language);
	}
//------
	public void addTreatment_Type(Treatment_Type treatment_Type) {
		System.out.println("********** OWLS.Profile.has_Treatment_Type*****"+OWLS.Profile.has_Treatment_Type);
	
	        addProperty(OWLS.Profile.has_Treatment_Type, treatment_Type);
	}
  

}
