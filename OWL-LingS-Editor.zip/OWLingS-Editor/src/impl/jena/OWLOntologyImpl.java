/*
 * Created on Dec 10, 2004
 */
package impl.jena;

import impl.owls.profile.LinguisticPhenomenonImpl;
import impl.owls.profile.ResourceImpl;
import impl.owls.profile.ServiceProcessing_LevelImpl;

import java.io.Reader;
import java.io.StringReader;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.mindswap.owl.OWLClass;
import org.mindswap.owl.OWLDataProperty;
import org.mindswap.owl.OWLDataValue;
import org.mindswap.owl.OWLEntity;
import org.mindswap.owl.OWLFactory;
import org.mindswap.owl.OWLIndividual;
import org.mindswap.owl.OWLIndividualList;
import org.mindswap.owl.OWLKnowledgeBase;
import org.mindswap.owl.OWLObjectProperty;
import org.mindswap.owl.OWLOntology;
import org.mindswap.owl.OWLProperty;
import org.mindswap.owl.OWLValue;
import org.mindswap.owls.service.Service;
import org.mindswap.owls.vocabulary.OWLS;

import com.hp.hpl.jena.datatypes.xsd.XSDDatatype;
import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.rdf.model.Literal;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.vocabulary.OWL;
import com.hp.hpl.jena.vocabulary.RDF;
import org.mindswap.owls.profile.LinguisticPhenomenon;     //Faten
import org.mindswap.owls.profile.Resource_Ling;  //Faten
import org.mindswap.owls.profile.ServiceProcessing_Level;   //Faten
//import org.mindswap.owls.profile.Resource;    //Faten

/**
 * @author Evren Sirin
 */
public class OWLOntologyImpl extends OWLModelImpl implements OWLOntology, org.mindswap.owls.OWLSOntology {
    private OWLKnowledgeBase kb;

    private OWLIndividual ontResource;

    private URI uri;
    private URI fileURI;

    private Map imports;

    private OWLOntology sourceOntology;

    public OWLOntologyImpl(OWLKnowledgeBase kb, URI uri, URI fileURI, Model jenaModel) {
        super(jenaModel);
        super.setBaseOntology(this);

        this.uri = uri;
        this.fileURI = fileURI;
        this.kb = kb;

        imports = new HashMap();

        sourceOntology = this;


    }

    public OWLKnowledgeBase getKB() {
        return kb;
    }

    public Set getImports() {
        return new HashSet( imports.values() );
    }

    public Set getImports(boolean direct) {
        if(!direct) {
            LinkedHashSet importsClosure = new LinkedHashSet();
            List orderedList = new ArrayList();
            orderedList.add( this );
            for( int i = 0; i < orderedList.size(); i++ ) {
                OWLOntology ont = (OWLOntology) orderedList.get( i );
                if( importsClosure.contains( ont ) )
                    continue;
                else
                    importsClosure.add( ont );

                for(Iterator it = ont.getImports().iterator(); it.hasNext();) {
                    OWLOntology imported = (OWLOntology) it.next();
                    if( importsClosure.contains( imported ) )
                        continue;
                    else
                        orderedList.add( imported );
                }
            }
            return importsClosure;
        }

        return getImports();
    }

    public void addImport(OWLOntology ontology) {
        URI fileURI = ontology.getFileURI();
        if( fileURI != null && !imports.containsKey( fileURI )) {            
            imports.put( fileURI, ontology );
        }
    }


    public void addImports(Set theImports) {
        Iterator aIter = theImports.iterator();
        while (aIter.hasNext()) {
            try {
                OWLOntology aOnt = (OWLOntology)aIter.next();
                addImport(aOnt);
            }
            catch (Exception ex) {
                // probably a cast exception, someone trying to add an ontology that
                // isnt actually an ontology object.  just ignore, try the next one
            }
        }
        //this.imports.addAll(theImports);
    }

    public OWLClass createClass(URI uri) {
        OWLClass c = getClass(uri);

        if(c == null) {
            Resource r = asResource(uri);
            ontModel.add(r, RDF.type, OWL.Class);
            kb.refresh();

            c = new OWLClassImpl(this, r);
        }

        return c;
    }

    public OWLObjectProperty createObjectProperty(URI uri) {
        OWLObjectProperty c = getObjectProperty(uri);

        if(c == null) {
            Property r = asProperty(uri);
            ontModel.add(r, RDF.type, OWL.ObjectProperty);
            kb.refresh();

            c = new OWLObjectPropertyImpl(this, r);
        }

        return c;
    }

    public OWLDataProperty createDataProperty(URI uri) {
        OWLDataProperty c = getDataProperty(uri);

        if(c == null) {
            Property r = asProperty(uri);
            ontModel.add(r, RDF.type, OWL.DatatypeProperty);
            kb.refresh();

            c = new OWLDataPropertyImpl(this, r);
        }

        return c;
    }

    public OWLIndividual createIndividual(URI uri) {
        OWLIndividual ind = getIndividual(uri);

        if(ind == null) {
            Resource r = asResource(uri);
            ind = new OWLIndividualImpl(this, r);

            kb.refresh();
        }

        return ind;
    }

    public OWLIndividual createInstance(OWLClass c) {
        Resource r = ontModel.createResource();
        ontModel.add(r, RDF.type, (Resource) c.getImplementation());
        OWLIndividual ind = new OWLIndividualImpl(this, r);
        kb.refresh();

        return ind;
    }

    public OWLIndividual createInstance(OWLClass c, URI uri) {
        Resource r = asResource(uri);
        ontModel.add(r, RDF.type, (Resource) c.getImplementation());
        OWLIndividual ind = new OWLIndividualImpl(this, r);
        kb.refresh();

        return ind;
    }

    public OWLDataValue createDataValue(String value) {
        return new OWLDataValueImpl(ontModel.createLiteral(value));
    }

    public OWLDataValue createDataValue(String value, String language) {
        return new OWLDataValueImpl(ontModel.createLiteral(value, language));
    }

    public OWLDataValue createDataValue(Object value, URI datatypeURI) {
        if(datatypeURI.equals(org.mindswap.owl.vocabulary.RDF.XMLLiteral))
            return new OWLDataValueImpl(ontModel.createLiteral(value.toString(), true));
        else
            return new OWLDataValueImpl(ontModel.createTypedLiteral(value, datatypeURI.toString()));
    }

    public OWLDataValue createDataValue(Object value) {
        if(value instanceof OWLDataValue )
            return (OWLDataValue) value;
        else if(value instanceof URI)
            return new OWLDataValueImpl(ontModel.createTypedLiteral(value, XSDDatatype.XSDanyURI));
        else
            return new OWLDataValueImpl(ontModel.createTypedLiteral(value));
    }

    public URI getURI() {
        return uri;
    }

    public URI getFileURI() {
        return fileURI;
    }

    /* (non-Javadoc)
     * @see org.mindswap.owl.OWLObject#debugString()
     */
    public String debugString() {
        return "Ontology (" + uri + ")";
    }

    /* (non-Javadoc)
     * @see org.mindswap.owl.OWLOntology#getOntologyObject()
     */
    public OWLEntity getOntologyObject() {
        return ontResource;
    }

    /* (non-Javadoc)
     * @see org.mindswap.owl.OWLOntology#asSingletonKB()
     */
    public OWLKnowledgeBase asKB() {
        return asKB(true);
    }

    /* (non-Javadoc)
     * @see org.mindswap.owl.OWLOntology#asSingletonKB(boolean)
     */
    public OWLKnowledgeBase asKB(boolean withImports) {
        OWLKnowledgeBase kb = OWLFactory.createKB();
        kb.load(this, withImports);

        return kb;

    }

    protected OWLDataValue wrapDataValue(Literal l, OWLOntology ont) {
        return new OWLDataValueImpl(l);
    }

    protected OWLIndividual wrapIndividual(Resource r, OWLOntology ont) {
        return new OWLIndividualImpl(this, r);
    }

    protected OWLClass wrapClass(Resource r, OWLOntology ont) {
        return new OWLClassImpl(this, r);
    }

    protected OWLObjectProperty wrapObjectProperty(Property p, OWLOntology ont) {
        return new OWLObjectPropertyImpl(this, p);
    }

    protected OWLDataProperty wrapDataProperty(Property p, OWLOntology ont) {
        return new OWLDataPropertyImpl(this, p);
    }

    public String toString() {
        if(uri == null)
            return "Ontology()";

        return "Ontology(" + uri + ")";
    }

    public void setURI(URI uri) {
        this.uri = uri;

        if(uri != null)
            ontResource = new OWLIndividualImpl(this, ontModel.getResource(uri.toString()));
    }

    public void setFileURI(URI uri) {
        this.fileURI = uri;
    }

//    public void setKB(OWLKnowledgeBase kb) {
//        this.kb = kb;
//    }

//    public void setImports(Set imports) {
//        this.imports = imports;
//    }

    public void refresh() {
        ontModel.rebind();
        kb.refresh();
    }

    public void setProperty(OWLIndividual ind, OWLDataProperty prop, String value) {
        setProperty(ind, prop, createDataValue(value));
    }

    
    public void setProperty(OWLIndividual ind, OWLDataProperty prop, Object value) {
        setProperty(ind, prop, createDataValue(value));
    }

    public void setProperty(OWLIndividual ind, OWLDataProperty prop, OWLDataValue value) {
        Resource subject = (Resource) ind.getImplementation();
        Property predicate = (Property) prop.getImplementation();
        Literal object = (Literal) value.getImplementation();

        ontModel.remove(ontModel.listStatements(subject, predicate, (Literal) null));
         ontModel.add(subject, predicate, object);
         kb.refresh();
    }

    public void addProperty(OWLIndividual ind, OWLProperty prop, OWLValue value) {
        if( prop instanceof OWLObjectProperty && value instanceof OWLIndividual )
            addProperty( ind, (OWLObjectProperty) prop, (OWLIndividual) value );
        else if( prop instanceof OWLDataProperty && value instanceof OWLDataValue )
            addProperty( ind, (OWLDataProperty) prop, (OWLDataValue) value );
        else
            throw new IllegalArgumentException();
    }

    public void addProperty(OWLIndividual ind, OWLDataProperty prop, OWLDataValue value) {
         ontModel.add(
            (Resource) ind.getImplementation(),
            (Property) prop.getImplementation(),
            (Literal)  value.getImplementation());
         kb.refresh();
    }


    public void addProperty(OWLIndividual ind, OWLDataProperty prop, String value) {
        addProperty(ind, prop, createDataValue(value));
    }

    public void addProperty(OWLIndividual ind, OWLDataProperty prop, Object value) {
        addProperty(ind, prop, createDataValue(value));
    }

    public void removeProperties(OWLIndividual ind, OWLProperty prop) {
        Resource subject = (Resource) ind.getImplementation();
        Property predicate = (Property) prop.getImplementation();

        ontModel.remove(ontModel.listStatements(subject, predicate, (Resource) null));
        kb.refresh();
    }

    public void removeProperty(OWLIndividual ind, OWLProperty prop, OWLValue value)
    {
        Resource subject = (Resource)ind.getImplementation();
        Property predicate = (Property)prop.getImplementation();
        RDFNode object = (RDFNode)value.getImplementation();

        Statement stmt = ontModel.createStatement(subject,predicate,object);

        ontModel.remove(stmt);

        refresh();
    }

    public void addProperty(OWLIndividual ind, OWLObjectProperty prop, OWLIndividual value) {
         ontModel.add(
            (Resource) ind.getImplementation(),
            (Property) prop.getImplementation(),
            (Resource) value.getImplementation());
         kb.refresh();
    }

    public void setProperty(OWLIndividual ind, OWLObjectProperty prop, OWLIndividual value) {
        Resource subject = (Resource) ind.getImplementation();
        Property predicate = (Property) prop.getImplementation();
        Resource object = (Resource) value.getImplementation();

        ontModel.remove(ontModel.listStatements(subject, predicate, (Resource) null));
         ontModel.add(subject, predicate, object);
         kb.refresh();
    }


    public void addType(OWLIndividual ind, OWLClass c) {
         ontModel.add(
            (Resource) ind.getImplementation(),
            RDF.type,
            (Resource) c.getImplementation());
         kb.refresh();
    }

    public void removeTypes(OWLIndividual ind) {
        Resource subject = (Resource) ind.getImplementation();

        ontModel.remove(ontModel.listStatements(subject, RDF.type, (Resource) null));
        kb.refresh();
    }

    public OWLOntology getTranslationSource() {
        return sourceOntology;
    }

    public void setTranslationSource(OWLOntology ontology) {
        sourceOntology = ontology;
    }

    public Service getService() {
        List list = getServices();

        return list.isEmpty() ? null : (Service) list.get(0);
    }

    public OWLIndividual parseLiteral(String literal) {
        Reader in = new StringReader( literal );
        OWLOntologyImpl ont = (OWLOntologyImpl) kb.read( in, uri );
        OWLIndividual res = null;
        int outCount = 0;

        OWLIndividualList instances = ont.getIndividuals();
        for(int i = 0; i < instances.size(); i++) {
            OWLIndividual ind = (OWLIndividual) instances.get( i );
            if(ont.getIncomingProperties(ind).isEmpty())
                return ind;
            if (res == null)
            {
                res = ind;
                outCount = ont.getProperties(ind).size();
            }
            else
            {
                int newCount = ont.getProperties(ind).size();
                if (newCount > outCount)
                {
                    res = ind;
                    outCount = newCount;
                }
            }
        }

        return res;
    }

    public OWLOntology union( OWLOntology  ont ) {
        // create empty ont
        OWLOntology newOnt = OWLFactory.createOntology();

        // add the contents of both ontologies
        newOnt.add( this );
        newOnt.add( ont );

        return newOnt;
    }

    public void add( OWLOntology  ont ) {
        Model m1 = ((OntModel) this.getImplementation()).getBaseModel();
        Model m2 = ((OntModel) ont.getImplementation()).getBaseModel();
        m1.add( m2 );

        kb.refresh();
    }

	public List getServices() {
		if (kb != null)
			return kb.getServices();
		
		return super.getServices();
	}

	@Override
/*	public LinguisticPhenomenon createLinguisticPhenomenon() {
		return null;
	} */
	/*	***********************	 Ajout� par Faten 	*************************	*/
  public LinguisticPhenomenon createLinguisticPhenomenon() { return createLinguisticPhenomenon(createInstance(OWLS.Profile.LinguisticPhenomenon)); }
  public LinguisticPhenomenon createLinguisticPhenomenon(URI uri) { return createLinguisticPhenomenon(createInstance(OWLS.Profile.LinguisticPhenomenon, uri)); }
  public LinguisticPhenomenon createLinguisticPhenomenon(OWLIndividual ind) {
      return new LinguisticPhenomenonImpl(ind);
  }
//------------------------------------- 	Faten : Le 23/07/2012  --------------------------------------
/*  public Resource_Ling createResource() { return createResource(createInstance(OWLS.Profile.Resource_Ling)); }
  public Resource_Ling createResource(URI uri) { 
	    System.out.println("============== OWLS.Profile.Resource_Ling ==========="+ OWLS.Profile.Resource_Ling);
	  return createResource(createInstance(OWLS.Profile.Resource_Ling, uri)); 
  }
  public Resource_Ling createResource(OWLIndividual ind) {
      return new ResourceImpl(ind);
  }
*/

  
/*  public ServiceProcessing_Level createServiceProcessing_Level() { return createServiceProcessing_Level(createInstance(OWLS.Profile.ServiceProcessing_Level)); }
  public ServiceProcessing_Level createServiceProcessing_Level(URI uri) { return createServiceProcessing_Level(createInstance(OWLS.Profile.ServiceProcessing_Level, uri)); }
  public ServiceProcessing_Level createServiceProcessing_Level(OWLIndividual ind) {
      return new ServiceProcessing_LevelImpl(ind);
  }*/
  
//*********************************************** pointeur  *************************************************************  
//------------- pointeur_Langage ----------------------------------------
  public void setPropertypointer_Langage(OWLIndividual ind,OWLObjectProperty prop, String value){
  	setPropertypointer_Langage(ind,prop,createDataValue(value));
  	}
  public void setPropertypointer_Langage(OWLIndividual ind, OWLObjectProperty prop, OWLDataValue value) {
      Resource subject = (Resource) ind.getImplementation();
      Property predicate = (Property) prop.getImplementation();
      Literal object = (Literal) value.getImplementation();

      ontModel.remove(ontModel.listStatements(subject, predicate, (Literal) null));
       ontModel.add(subject, predicate, object);
       kb.refresh();
  }
//------------- pointeur_TreatmentType ----------------------------------------
  public void setPropertypointer_TreatmentType(OWLIndividual ind,OWLObjectProperty prop, String value){
  	setPropertypointer_TreatmentType(ind,prop,createDataValue(value));
  	}
  public void setPropertypointer_TreatmentType(OWLIndividual ind, OWLObjectProperty prop, OWLDataValue value) {
      Resource subject = (Resource) ind.getImplementation();
      Property predicate = (Property) prop.getImplementation();
      Literal object = (Literal) value.getImplementation();

      ontModel.remove(ontModel.listStatements(subject, predicate, (Literal) null));
       ontModel.add(subject, predicate, object);
       kb.refresh();
  }
//------------- pointeur_PL ----------------------------------------
  public void setPropertypointer_PL(OWLIndividual ind,OWLObjectProperty prop, String value){
  	setPropertypointer_PL(ind,prop,createDataValue(value));
  	}
  public void setPropertypointer_PL(OWLIndividual ind, OWLObjectProperty prop, OWLDataValue value) {
      Resource subject = (Resource) ind.getImplementation();
      Property predicate = (Property) prop.getImplementation();
      Literal object = (Literal) value.getImplementation();

      ontModel.remove(ontModel.listStatements(subject, predicate, (Literal) null));
       ontModel.add(subject, predicate, object);
       kb.refresh();
  }
//------------- pointeur_Resource ----------------------------------------
  public void setPropertypointer_Resource(OWLIndividual ind,OWLObjectProperty prop, String value){
  	setPropertypointer_Resource(ind,prop,createDataValue(value));
  	}
  public void setPropertypointer_Resource(OWLIndividual ind, OWLObjectProperty prop, OWLDataValue value) {
      Resource subject = (Resource) ind.getImplementation();
      Property predicate = (Property) prop.getImplementation();
      Literal object = (Literal) value.getImplementation();

      ontModel.remove(ontModel.listStatements(subject, predicate, (Literal) null));
       ontModel.add(subject, predicate, object);
       kb.refresh();
  }
//------------- pointeur_Phenomenon ----------------------------------------
  public void setPropertypointer_Phenomenon(OWLIndividual ind,OWLObjectProperty prop, String value){
  	setPropertypointer_Phenomenon(ind,prop,createDataValue(value));
  	}
  public void setPropertypointer_Phenomenon(OWLIndividual ind, OWLObjectProperty prop, OWLDataValue value) {
      Resource subject = (Resource) ind.getImplementation();
      Property predicate = (Property) prop.getImplementation();
      Literal object = (Literal) value.getImplementation();

      ontModel.remove(ontModel.listStatements(subject, predicate, (Literal) null));
       ontModel.add(subject, predicate, object);
       kb.refresh();
  }
//------------- pointeur_Formalism ----------------------------------------
  public void setPropertypointer_Formalism(OWLIndividual ind,OWLObjectProperty prop, String value){
  	setPropertypointer_Formalism(ind,prop,createDataValue(value));
  	}
  public void setPropertypointer_Formalism(OWLIndividual ind, OWLObjectProperty prop, OWLDataValue value) {
      Resource subject = (Resource) ind.getImplementation();
      Property predicate = (Property) prop.getImplementation();
      Literal object = (Literal) value.getImplementation();

      ontModel.remove(ontModel.listStatements(subject, predicate, (Literal) null));
       ontModel.add(subject, predicate, object);
       kb.refresh();
  }
//------------- pointeur_Analysis_type ----------------------------------------
  public void setPropertypointer_Analysis_type(OWLIndividual ind,OWLObjectProperty prop, String value){
  	setPropertypointer_Analysis_type(ind,prop,createDataValue(value));
  	}
  public void setPropertypointer_Analysis_type(OWLIndividual ind, OWLObjectProperty prop, OWLDataValue value) {
      Resource subject = (Resource) ind.getImplementation();
      Property predicate = (Property) prop.getImplementation();
      Literal object = (Literal) value.getImplementation();

      ontModel.remove(ontModel.listStatements(subject, predicate, (Literal) null));
       ontModel.add(subject, predicate, object);
       kb.refresh();
  }

//------------- pointeur_Approach ----------------------------------------
  public void setPropertypointer_Approach(OWLIndividual ind,OWLObjectProperty prop, String value){
  	setPropertypointer_Approach(ind,prop,createDataValue(value));
  	}
  public void setPropertypointer_Approach(OWLIndividual ind, OWLObjectProperty prop, OWLDataValue value) {
      Resource subject = (Resource) ind.getImplementation();
      Property predicate = (Property) prop.getImplementation();
      Literal object = (Literal) value.getImplementation();

      ontModel.remove(ontModel.listStatements(subject, predicate, (Literal) null));
       ontModel.add(subject, predicate, object);
       kb.refresh();
  }
  
  //----------------------------------------------------------------------

}
