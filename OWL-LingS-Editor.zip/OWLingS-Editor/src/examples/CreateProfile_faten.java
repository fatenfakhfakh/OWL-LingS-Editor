//  http://code.google.com/p/jaafjasof/source/browse/trunk/owls/CreateProfile.java?r=3
package examples;

import java.io.IOException;
import java.net.URI;

import org.mindswap.owl.OWLFactory;
import org.mindswap.owl.OWLIndividual;
import org.mindswap.owl.OWLOntology;
import org.mindswap.owl.OWLType;
import org.mindswap.owls.grounding.WSDLAtomicGrounding;
//import org.mindswap.owls.grounding.WSDLGrounding;
import org.mindswap.owls.process.AtomicProcess;
//import org.mindswap.owls.process.variable.Input;
//import org.mindswap.owls.process.variable.Output;
import org.mindswap.owls.process.Input;
import org.mindswap.owls.process.Output;
import org.mindswap.owls.profile.Profile;
import org.mindswap.owls.profile.ServiceParameter;
import org.mindswap.owls.service.Service;
import org.mindswap.utils.URIUtils;

public class CreateProfile_faten {

        public static void main(final String[] args) throws Exception
        {
                final CreateProfile_faten test = new CreateProfile_faten();
                test.run();
        }

        public void run() throws Exception
        {
                createProfileCQCaseStudy();

        }
        
//////////////////////////////GeoRisc//////////////////////////////
        
        //////////////////////////////Combinao Qualitativa//////////////////////////////
        public void createProfileCQCaseStudy() throws IOException{
                //final URI baseURI = URI.create("http://localhost:8083/WeOWL/Georisc.owl");
        		final URI baseURI = URI.create("http://127.0.0.1/ontology/books.owl");
        		System.out.println("*****************	11111	******************** ");

                //String ont1 = "file:/Users/baldoino/Desktop/Concepts/georisc.owl";
                String ont1 = "file:///E:/addition2_f1.owl";
                System.out.println("*****************	2222	******************** ");

                final OWLOntology ont = OWLFactory.createKB().read(URI.create(ont1));
                System.out.println("*****************	ont	=========== "+ont);

                final Service service = ont.createService(URIUtils.createURI(baseURI, "Service"));
                System.out.println("*****************	service	=========== "+service);

                final Profile profile = ont.createProfile(URIUtils.createURI(baseURI, "Profile"));
                System.out.println("*****************	profile	=========== "+profile);

                //////////////////////////////Service Name //////////////////////////////
                profile.setServiceName("Combinao Qualitativa");
                
                //////////////////////////////Service Parameter //////////////////////////////
                //ServiceParameter serviceParameterTR = ont.createServiceParameter(URIUtils.createURI(ont1 +"#ResponseTimeQuality"));
               // ServiceParameter serviceParameterTR = ont.createServiceParameter(URIUtils.createURI(ont1 +"#a"));
                //System.out.println("*****************	serviceParameterTR	=========== "+serviceParameterTR);

                //OWLIndividual owlIndividualTR = ont.getIndividual(URI.create("http://www.owl-ontologies.com/georisc.owl#average")); 
                OWLIndividual owlIndividualTR = ont.getIndividual(URI.create("http://127.0.0.1/ontology/books.owl#Book")); 
                  System.out.println("*****************	owlIndividualTR========== "+owlIndividualTR);

                //serviceParameterTR.setParameter(owlIndividualTR);
                //serviceParameterTR.setName("TempodeResposta");
                
                //profile.addServiceParameter(serviceParameterTR);
                 System.out.println("*****************	profile	=222%%%%%%%%%%%%%%%========== "+profile);

                ServiceParameter serviceParameterS = ont.createServiceParameter(URIUtils.createURI(ont1 +"#SecurityQuality"));
                
                OWLIndividual owlIndividualS = ont.getIndividual(URI.create("http://www.owl-ontologies.com/georisc.owl#excellent")); 
                serviceParameterS.setParameter(owlIndividualS);
                serviceParameterS.setName("Seguranca");
                                
                profile.addServiceParameter(serviceParameterS);
                
                System.out.println("*****************	profile	=33333%%%%%%%%%%%%%%%========== "+profile);

                ServiceParameter serviceParameterES = ont.createServiceParameter(URIUtils.createURI(ont1 +"#EscalabilityQuality"));
                
                OWLIndividual owlIndividualES = ont.getIndividual(URI.create("http://www.owl-ontologies.com/georisc.owl#excellent")); 
                serviceParameterES.setParameter(owlIndividualES);
                serviceParameterES.setName("Escalabilidade");
                
                profile.addServiceParameter(serviceParameterES);
                
                ServiceParameter serviceParameterC = ont.createServiceParameter(URIUtils.createURI(ont1 +"#CostQuality"));
                
                OWLIndividual owlIndividualC = ont.getIndividual(URI.create("http://www.owl-ontologies.com/georisc.owl#average")); 
                serviceParameterC.setParameter(owlIndividualC);
                serviceParameterC.setName("Custo");
                
                profile.addServiceParameter(serviceParameterC);

                //////////////////////////////Inputs //////////////////////////////
                
                final AtomicProcess process = ont.createAtomicProcess(URIUtils.createURI(baseURI, "Process"));
                service.setProcess(process);
                
                final Input input1 = ont.createInput(URIUtils.createURI(baseURI, "Vegetao"));
                OWLType owlTypeVegetation = ont.getType(URIUtils.createURI("http://www.owl-ontologies.com/georisc.owl#Vegetacao"));
                input1.setParamType(owlTypeVegetation);
                profile.addInput(input1);
                process.addInput(input1);
                                
                final Input input2 = ont.createInput(URIUtils.createURI(baseURI, "Evidncia"));
                OWLType owlTypeEvidence = ont.getType(URIUtils.createURI("http://www.owl-ontologies.com/georisc.owl#Evidencias"));
                input2.setParamType(owlTypeEvidence);
                profile.addInput(input2);
                process.addInput(input2);
                
                final Input input3 = ont.createInput(URIUtils.createURI(baseURI, "Declividade"));
                OWLType owlTypeSlope = ont.getType(URIUtils.createURI("http://www.owl-ontologies.com/georisc.owl#Declividade"));
                input3.setParamType(owlTypeSlope);
                profile.addInput(input3);
                process.addInput(input3);
                        
                //////////////////////////////OutPuts //////////////////////////////
                final Output output = ont.createOutput(URIUtils.createURI(baseURI, "Risk"));
                OWLType owlTypeConfirmation = ont.getType(URIUtils.createURI("http://www.owl-ontologies.com/georisc.owl#Risk"));
                output.setParamType(owlTypeConfirmation);
                profile.addOutput(output);
                process.addOutput(output);
                
                
                //////////////////////////////WSDLGrounding //////////////////////////////              
            /*  ************* Supp par Faten
                 final WSDLAtomicGrounding jAtomicGround = ont.createWSDLAtomicGrounding(URIUtils.createURI(baseURI, "AtomGround"));
             
                jAtomicGround.setProcess(process);
                jAtomicGround.setWSDL(URIUtils.createURI("http://localhost:8080/HelloImpl/HelloImplService?wsdl"));
                jAtomicGround.setProcess(process);
                
                final WSDLGrounding jGrounding = ont.createWSDLGrounding(URIUtils.createURI(baseURI, "Grounding"));
                jGrounding.addGrounding(jAtomicGround);
                jGrounding.setService(service);
                
                service.addProfile(profile);
                
                ont.write(System.out, baseURI);
             */
        }

      
        
        
}
